from flask import Flask, render_template, request, jsonify


app = Flask(__name__)

database = {
    'user': '123'  # username: password
}


# Route for rendering the main page
@app.route('/')
def index():
    return render_template('Login.html')

# Route to handle login
@app.route('/form_login', methods=['POST', 'GET'])
def login():
    # Get username and password from the form
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Validate credentials
    if username not in database:
        return render_template('login.html', info='Invalid Username')
    elif database[username] != password:
        return render_template('login.html', info='Invalid Password')
    else:
        return render_template('home.html', name=username)
    
# Route for rendering the registration page
@app.route('/registration')
def registration():
    return render_template('registration.html')

# Route to handle registration form submission
@app.route('/form_registration', methods=['POST'])
def form_registration():
    # Get username and password from the form
    username = request.form.get('username')
    password = request.form.get('password')

    # Check if the username already exists
    if username in database:
        return render_template('registration.html', info='Username already exists!')
    
    # Add the new user to the database
    database[username] = password
    return render_template('login.html', info='Registration successful! Please log in.')

 

# API endpoint to handle the form submission
# @app.route('/submit', methods=['POST'])
# def handle_prompt():
#     input_prompt = request.json['prompt']

#     result=getPrompt(input_prompt)
#     altered_prompt=result.replace('"',"")

#     original_result = getResults(input_prompt)
#     print(altered_prompt)
#     altered_result = getResults(altered_prompt)

#     return jsonify({
#         'originalResult': original_result,
#         'alteredResult': altered_result
#     })
@app.route('/auditory_learning')
def auditory_learning():
    return render_template('Auditory_learning.html')

@app.route('/reading_writing_learning')
def reading_writing_learning():
    return render_template('R&W_learning.html')

@app.route('/visual_learning')
def visual_learning():
    return render_template('Visual_learning.html')

@app.route('/kinesthetic_learning')
def kinesthetic_learning():
    return render_template('Kinesthetic_learning.html')

if __name__ == '__main__':
    app.run(debug=True)